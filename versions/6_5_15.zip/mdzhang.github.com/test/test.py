
import glob

for name in glob.glob('../*'):
  print name